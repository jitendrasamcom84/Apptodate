
<?php
 /*
    *
    Template Name: Project
    */

    get_header('project'); ?>
    

  <?php
	get_footer(); ?>