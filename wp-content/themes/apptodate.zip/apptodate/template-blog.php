<?php
    /*
    *
    Template Name: Blog Page
    */
    get_header('blog'); ?>
     <div class="container">
      <div class="scroll_aritical">
          <div class="artical_part_blog_background">
            <div class="row">
             <div class="col-md-6 col-xs-12 col-sm-6 artical_contant_part">
                <div class="artical_contant_background">
                   <h2>כותרת מאמר שכתבנו בנושא של דברים טכנולוגים</h2>
                   <p>לורם איפסום דולור סיט אמט, קונסקטורר אדיפיסינג אלית צש בליא, מנסוטו צמלח לביקו ננבי, צמוקו בלוקריה שיצמה ברורק. קולורס מונפרד אדנדום סילקוף, מרגשי ומרגשח. עמחליף קולהע צופעט למרקוח איבן איף, ברומץ כלרשט מיחוצים. קלאצי סחטיר בלובק. תצטנפל בלינדו למרקל אס לכימפו, דול, צוט ומעיוט - לפתיעם ברשג ולתיעם גדדיש. קוויז דומור ליאמום בלינך רוגצה. לפמעט</p>  
                   
                   <a href="specific_blog.html" class="trigger1 loadme1 pull-right w45">
                     <div class="post-header">
                        <p class="project-btn1 relate_pos cus_posa w50pxs"><img id="ask" src="<?php echo get_template_directory_uri(); ?>/img/leftarrow_b.png" class="arrow_b_pos"></p>
                     </div>
                   </a> 
                </div>
             </div>

             <div class="col-md-6 col-xs-12 col-sm-6 artical_image_part">
                <div class="artical_image_background">
                   <img src="<?php echo get_template_directory_uri(); ?>/img/blog.png">
                </div>
             </div>  
             </div>
          </div>

          <div class="artical_part_blog_background">
            <div class="row">
             <div class="col-md-6 col-xs-12 col-sm-6 artical_contant_part">
                <div class="artical_contant_background">
                   <h2>כותרת מאמר שכתבנו בנושא של דברים טכנולוגים</h2>
                   <p>לורם איפסום דולור סיט אמט, קונסקטורר אדיפיסינג אלית צש בליא, מנסוטו צמלח לביקו ננבי, צמוקו בלוקריה שיצמה ברורק. קולורס מונפרד אדנדום סילקוף, מרגשי ומרגשח. עמחליף קולהע צופעט למרקוח איבן איף, ברומץ כלרשט מיחוצים. קלאצי סחטיר בלובק. תצטנפל בלינדו למרקל אס לכימפו, דול, צוט ומעיוט - לפתיעם ברשג ולתיעם גדדיש. קוויז דומור ליאמום בלינך רוגצה. לפמעט</p> 

                   <a href="specific_blog.html" class="trigger2 loadme1 pull-right w45">
                     <div class="post-header">
                        <p class="project-btn1 relate_pos cus_posa w50pxs">
                          <img id="ask1" src="<?php echo get_template_directory_uri(); ?>/img/leftarrow_b.png" class="arrow_b_pos">
                        </p>
                     </div>
                   </a>  
                </div>
             </div>

             <div class="col-md-6 col-xs-12 col-sm-6 artical_image_part">
                <div class="artical_image_background">
                   <img src="<?php echo get_template_directory_uri(); ?>/img/blog_artical_2.png">
                </div>
             </div>  
             </div>
          </div>

          <div class="artical_part_blog_background">
            <div class="row">
             <div class="col-md-6 col-xs-12 col-sm-6 artical_contant_part">
                <div class="artical_contant_background">
                   <h2>כותרת מאמר שכתבנו בנושא של דברים טכנולוגים</h2>
                   <p>לורם איפסום דולור סיט אמט, קונסקטורר אדיפיסינג אלית צש בליא, מנסוטו צמלח לביקו ננבי, צמוקו בלוקריה שיצמה ברורק. קולורס מונפרד אדנדום סילקוף, מרגשי ומרגשח. עמחליף קולהע צופעט למרקוח איבן איף, ברומץ כלרשט מיחוצים. קלאצי סחטיר בלובק. תצטנפל בלינדו למרקל אס לכימפו, דול, צוט ומעיוט - לפתיעם ברשג ולתיעם גדדיש. קוויז דומור ליאמום בלינך רוגצה. לפמעט</p>  
                   
                   <a href="specific_blog.html" class="trigger3 loadme1 pull-right w45">
                     <div class="post-header">
                        <p class="project-btn1 relate_pos cus_posa w50pxs"><img id="ask2" src="<?php echo get_template_directory_uri(); ?>/img/leftarrow_b.png" class="arrow_b_pos"></p>
                     </div>
                   </a>  
                </div>
             </div>

             <div class="col-md-6 col-xs-12 col-sm-6 artical_image_part">
                <div class="artical_image_background">
                   <img src="<?php echo get_template_directory_uri(); ?>/img/blog_arical_3.png">
                </div>
             </div>  
             </div>
          </div>
          
          <div class="artical_part_blog_background">
            <div class="row">
             <div class="col-md-6 col-xs-12 col-sm-6 artical_contant_part">
                <div class="artical_contant_background">
                   <h2>כותרת מאמר שכתבנו בנושא של דברים טכנולוגים</h2>
                   <p>לורם איפסום דולור סיט אמט, קונסקטורר אדיפיסינג אלית צש בליא, מנסוטו צמלח לביקו ננבי, צמוקו בלוקריה שיצמה ברורק. קולורס מונפרד אדנדום סילקוף, מרגשי ומרגשח. עמחליף קולהע צופעט למרקוח איבן איף, ברומץ כלרשט מיחוצים. קלאצי סחטיר בלובק. תצטנפל בלינדו למרקל אס לכימפו, דול, צוט ומעיוט - לפתיעם ברשג ולתיעם גדדיש. קוויז דומור ליאמום בלינך רוגצה. לפמעט</p>  
                   
                   <a href="specific_blog.html" class="trigger4 loadme1 pull-right w45">
                     <div class="post-header">
                        <p class="project-btn1 relate_pos cus_posa w50pxs"><img id="ask3" src="<?php echo get_template_directory_uri(); ?>/img/leftarrow_b.png" class="arrow_b_pos"></p>
                     </div>
                   </a> 
                </div>
             </div>

             <div class="col-md-6 col-xs-12 col-sm-6 artical_image_part">
                <div class="artical_image_background">
                   <img src="<?php echo get_template_directory_uri(); ?>/img/blog_artical_4.png">
                </div>
             </div>  
             </div>
          </div>
        </div>
    </div>

    <div class="section_form">

        <div class="container-fluid nopadding">
            <div class="col-lg-2 hidden-xs hidden-sm hidden-md nopadding"><img src="<?php echo get_template_directory_uri(); ?>/img/a1.png" class="a_pos1"></div>

            <!-- <div class="bg_app"></div> -->

            <div class="col-md-12 col-lg-8 padding_lr_20">
                <div class="mycontainer">
                    <h1 class="color_white padding-bottom50 text-center font46 bold margin_tb_0">אנחנו תמיד עונים, גם למכתבי שרשרת
                    </h1>

                    <div class="custom_bg">
                        <div class="full_div back_white padding20 cus_shadow">
                            <form>
                                <div class="col-xs-12 col-sm-6 right">
                                    <div class="form-group margin_b_55">
                                        <label class="font28 bold" for="exampleInputUsername">שם</label>
                                        <input type="text" class="form-control padding_lr0" id="" placeholder="כי לא נגיד סתם היוש">
                                    </div>
                                    <div class="form-group margin_b_55">
                                        <label class="font28 bold" for="exampleInputEmail">מייל</label>
                                        <input type="email" class="form-control padding_lr0" id="exampleInputEmail" placeholder="זה שדה חובה">
                                    </div>
                                    <div class="form-group small_55b">
                                        <label class="font28 bold" for="telephone">טלפון</label>
                                        <input type="tel" class="form-control padding_lr0" id="telephone" placeholder="עוד קצת, זה באמת שדה חובה">
                                    </div>
                                </div>
                                <div class="col-xs-12 col-sm-6 form-line">
                                    <div class="form-group set_pos">
                                        <label class="font28 bold" for="description"> על מה נדבר?</label>
                                        <textarea class="form-control padding_lr0" id="description" placeholder="ספרו לנו בכמה מילים"></textarea>
                                    </div>

                                    <div class="text-center set_pos">

                                        <a class="grad_button grad_button--gradient" href="#link">שלח</a>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-2 hidden-xs hidden-sm hidden-md nopadding"><img src="<?php echo get_template_directory_uri(); ?>/img/a2.png" class="a_pos2"></div>
        </div>
    </div>
           
<?php get_footer(); ?>