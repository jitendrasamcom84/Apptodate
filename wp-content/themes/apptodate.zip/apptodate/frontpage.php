<?php
    /*
    *
    Template Name: Full-Width
    */
    //get_header('blog'); ?>                  
    
           
<?php //get_footer(); ?>