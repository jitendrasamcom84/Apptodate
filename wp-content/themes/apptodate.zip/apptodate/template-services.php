
<?php
 /*
    *
    Template Name: services
    */

    get_header('services'); ?>
    

  <?php
	get_footer(); ?>